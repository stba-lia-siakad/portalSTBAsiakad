<div class="container-fluid">
                <nav class="pull-left">
                    
                </nav>
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> STBA LIA Yogyakarta</a> All right Reserved.
                </p>
            </div>