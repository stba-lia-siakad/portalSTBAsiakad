</br> 
<a href="?page=dashboard" class="simple-text">
                <img src="<?php echo base_url('assets/img/stbawite.png')?>" width="220"height="110" alt="" /> 
                   
                   </br></br><hr size="1px" width="200px">Admin Panel - Keuangan
                </a>

