<div class="card">  
    <div class="header" >
    <div class="container">
         <div class="header" >
                 <h4 class="title">Input Data Mahasiswa</h4>
                 <p class="category">STBA LIA Yogyakarta</p>
             <hr/>
         </br>
    </div>
    <div class="page">
    <div class="page-content container-fluid">
        <div class="row" data-plugin="matchHeight" data-by-row="true">
            <div class="col-xxl-12">
                <div id="teamCompletedWidget">
                    <div class="card-block p-20 pb-25">
                        <div class="row pb-40" data-plugin="matchHeight">
                            <div class="col-md-6">
                                
                            </div>
                        </div>
                        <div class="row" style="margin-top: -40px" data-plugin="matchHeight">
                            <div class="col-md-12">
                                <br>
                                <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="varchar">NIM
                                            <?php echo form_error('nim') ?></label>
                                        <input type="text" <?php if($nim){echo 'readonly';} ?> class="form-control" name="nim" id="nim" placeholder="NIM" value="<?php echo $nim; ?>" required autofocus/>
                                    </div>
                                    <div class="form-group">
                                        <label for="varchar">NIK
                                            <?php echo form_error('nik')?></label>
                                            <input type="text" class="form-control" name="nik" id="nik" placeholder="NIK" value="<?php echo $nik; ?>" />
                                    </div>
                                    <div class="form-group">
                                        <label for="varchar">Nama
                                            <?php echo form_error('nama_mhs') ?></label>
                                        <input type="text" class="form-control" name="nama_mhs" id="nama_mhs" placeholder="Nama" value="<?php echo $nama_mhs; ?>" />
                                    </div>
                                    <div class="form-group">
                                        <label for="varchar">Tempat Lahir
                                            <?php echo form_error('tempat_lahir_mhs') ?></label>
                                        <input type="text" class="form-control" name="tempat_lahir_mhs" id="tempat_lahir_mhs" placeholder="Tempat Lahir" value="<?php echo $tempat_lahir_mhs; ?>" />
                                    </div>
                                    <div class="form-group">
                                        <label for="date">Tanggal Lahir
                                            <?php echo form_error('tgl_lahir_mhs') ?></label>
                                        <input type="date" class="form-control" name="tgl_lahir_mhs" id="tgl_lahir_mhs" placeholder="Tgl Lahir" value="<?php echo $tgl_lahir_mhs; ?>" />
                                    </div>
                                    <div class="form-group">
                                        <label for="enum">Jenis Kelamin
                                            <?php echo form_error('gender_mhs') ?></label>
                                        <select class="form-control" name="gender_mhs">
                                            <option>- Jenis Kelamin -</option>
                                            <option value="L" <?php if($gender_mhs=='L'){ echo 'selected';} ?>>Laki - laki</option>
                                            <option value="P" <?php if($gender_mhs=='P'){ echo 'selected';} ?>>Perempuan</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="varchar">Asal SMA/MA/MK/SMK
                                            <?php echo form_error('nama_mhs') ?></label>
                                        <input type="text" class="form-control" name="asal_sma" id="asal_sma" placeholder="Asal SMA/MA/MK/SMK" value="<?php echo $asal_sma; ?>" />
                                    </div>
                                    <div class="form-group">
                                        <label for="enum">Agama
                                            <?php echo form_error('agama_mhs') ?></label>
                                        <select class="form-control" name="agama_mhs">
                                            <option>- Agama -</option>
                                            <option value="Islam" <?php if($agama_mhs=='Islam'){ echo 'selected';} ?>>Islam</option>
                                            <option value="Kristen" <?php if($agama_mhs=='Kristen'){ echo 'selected';} ?>>Kristen</option>
                                            <option value="Katolik" <?php if($agama_mhs=='Katolik'){ echo 'selected';} ?>>Katolik</option>
                                            <option value="Budha" <?php if($agama_mhs=='Budha'){ echo 'selected';} ?>>Budha</option>
                                            <option value="Hindu" <?php if($agama_mhs=='Hindu'){ echo 'selected';} ?>>Hindu</option>
                                            <option value="Kong Hu Chu" <?php if($agama_mhs=='Kong Hu Chu'){ echo 'selected';} ?>>Kong Hu Chu</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="int">Status Masuk
                                            <?php echo form_error('id_st_msk') ?></label>
                                        
                                        <select class="form-control" name="id_st_msk">
                                            <option>- Status -</option>
                                            <option value="1" <?php if($id_st_msk=='1'){ echo 'selected';} ?>>Baru</option>
                                            <option value="2" <?php if($id_st_msk=='2'){ echo 'selected';} ?>>Transfer</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="varchar">Nama Ibu Kandung
                                            <?php echo form_error('nama_ibu_kandung')?>
                                        </label>
                                        <input type="text" class="form-control" name="nama_ibu_kandung" id="nama_ibu_kandung" placeholder="Nama Ibu Kandung" value="<?php echo $nama_ibu_kandung ?>" />
                                    </div>
                                    <div class="form-group">
                                        <label for="tinyint">SKS Diakui
                                            <?php echo form_error('sks_diakui') ?></label>
                                        <input type="text" class="form-control" name="sks_diakui" id="sks_diakui" placeholder="Sks Diakui" value="<?php echo $sks_diakui; ?>" />
                                    </div>
                                    

                                     <div class="form-group">
                                        <label for="int">Angkatan
                                            <?php echo form_error('angkatan') ?></label>
                                        
                                        <select class="form-control" name="angkatan">
                                            <option>- Angkatan -</option>
                                            <option value="1" <?php if($angkatan=='1'){ echo 'selected';} ?>>2017</option>
                                            <option value="2" <?php if($angkatan=='2'){ echo 'selected';} ?>>2018</option>
                                            <option value="3" <?php if($angkatan=='3'){ echo 'selected';} ?>>2019</option>
                                            <option value="4" <?php if($angkatan=='4'){ echo 'selected';} ?>>2020</option>
                                            <option value="5" <?php if($angkatan=='5'){ echo 'selected';} ?>>2021</option>
                                            <option value="6" <?php if($angkatan=='6'){ echo 'selected';} ?>>2022</option>
                                            <option value="7" <?php if($angkatan=='7'){ echo 'selected';} ?>>2023</option>
                                            <option value="8" <?php if($angkatan=='8'){ echo 'selected';} ?>>2024</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="int">Jurusan
                                            <?php echo form_error('id_jenjang') ?></label>
                                        <select name="id_jenjang" class="form-control">
                                            <option>- Jurusan -</option>
                                            <?php
                                            $text='';
                                            foreach($jurusans as $data){
                                                if($id_jenjang==$data->id_jurusan){
                                                    $text='selected';
                                                }
                                            ?>
                                            <option <?= $text ?> value="<?= $data->id_jurusan ?>"><?= $data->nama_jenjang.' - '.$data->nama_jurusan ?></option>
                                            <?php
                                            $text='';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="int">Beasiswa
                                            <?php echo form_error('id_beasiswa') ?></label>
                                        <select name="id_beasiswa" class="form-control">
                                            <option>Beasiswa</option>
                                            <?php
                                            $text='';
                                            foreach($beasiswa as $data){
                                                if($id_beasiswa==$data->id_beasiswa){
                                                    $text='selected';
                                                }
                                            ?>
                                            <option <?= $text ?> value="<?= $data->id_beasiswa ?>"><?= $data->id_beasiswa.' - '.$data->nama_beasiswa ?></option>
                                            <?php
                                            $text='';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="int">Nomor WA
                                            <?php echo form_error('nowa') ?></label>
                                    <input type="int" name="nowa" class="form-control" placeholder="Nomor WA"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="int">Email
                                            <?php echo form_error('email') ?></label>
                                    <input type="email" name="email" class="form-control" placeholder="Email"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="int">Minat dan Hobi
                                            <?php echo form_error('mdh') ?></label>
                                    <input type="text" name="mdh" class="form-control" placeholder="Minat dan Hobi"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="int">Prestasi
                                            <?php echo form_error('prestasi') ?></label>
                                    <input type="text" name="prestasi" class="form-control" placeholder="Prestasi"/>
                                    </div>
                                    <div> <label for="int">Alamat Asal
                                            <?php echo form_error('alamat_a') ?></label>
                                            <textarea id="ckeditor" name="alamat_a" class="form-control" required></textarea><br/></div>
                                    <div> <label for="int">Alamat Sekarang
                                            <?php echo form_error('alamat_s') ?></label>
                                            <textarea id="ckeditor" name="alamat_s" class="form-control" required></textarea><br/></div>
                                    <div class="form-group">
                                        <label for="varchar">Foto
                                            <?php echo form_error('img_file') ?></label>
                                        <input type="file" class="form-control" name="img_file" id="img_file" accept="image/jpeg"/>
                                    </div>

                                    
                                    <!-----------------
                                    <div class="form-group">
                                        <label for="varchar">Foto Mhs
                                            <?php echo form_error('foto_mhs') ?></label>
                                        <input type="text" class="form-control" name="foto_mhs" id="foto_mhs" placeholder="Foto Mhs" value="<?php echo $foto_mhs; ?>" />
                                    </div>
                                    ----------------------->
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo $button ?></button>
                                    <a href="<?php echo site_url('admin/baak/mahasiswa') ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i> Kembali</a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
</div>
        </div>
    </div>
</div>
</br>