
        <table class="table">
	    <tr><td>Nama Ruangan</td><td><?php echo $nama_ruangan; ?></td></tr>
	    <tr><td>Tipe Ruangan</td><td><?php echo $tipe_ruangan; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('room') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
