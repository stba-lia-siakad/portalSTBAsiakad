            <ul class="nav">
                <li>
                    <a href="<?php echo site_url('admin/home') ?>">
                        <i class="pe-7s-home"></i>
                        <p>HOME</p>
                    </a>
                </li>
                
                
                <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="pe-7s-notebook"></i><p>PLOTING<b class="caret"></b></p></a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo site_url('admin/kajur/ploting') ?>"><font color="black"><i class="pe-7s-door-lock"></i><p>Kelas</p></a></font></li>
                <li><a href="<?php echo site_url('admin/kajur/plot_kelas') ?>"><font color="black"><i class="pe-7s-paperclip"></i><p>Mata Kuliah</p></a></font></li>
              </ul>
                </li>
                
                <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="pe-7s-date"></i><p>PENJADWALAN<b class="caret"></b></p></a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo site_url('krs/jadwal') ?>"><font color="black"><i class="pe-7s-file"></i><p>KRS</p></a></font></li>
                <li><a href="<?php echo site_url('jadwal') ?>"><font color="black"><i class="pe-7s-paperclip"></i><p>Mata Kuliah</p></a></font></li>
              </ul>
                </li>
                <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="pe-7s-pin"></i><p>PENGUMUMAN<b class="caret"></b></p></a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo site_url('post_berita/lists') ?>"><font color="black"><i class="pe-7s-file"></i><p>Lihat Pengumuman</p></a></font></li>
                <li><a href="<?php echo site_url('post_berita') ?>"><font color="black"><i class="pe-7s-paperclip"></i><p>Buat Pengumuman</p></a></font></li>
              </ul>
                </li>                                
                </li>
                <li>
                    <a href="<?php echo site_url('admin/tes/index.php') ?>">
                        <i class="pe-7s-graph2"></i>
                        <p>LAPORAN</p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo site_url('akun/konfig') ?>">
                        <i class="pe-7s-config"></i>
                        <p>KONFIGURASI</p>
                    </a>
                </li>
                <br/>
                <br/>
                <br/>
                <hr/>
        <div class="alert alert-white" role="alert">
            <center style="color: #fff;">

        <?php echo date('l, d F Y');?>
        <hr/>
        </center>
<html>
<head>
<script>
function startTime() {
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds();
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById('txt').innerHTML =
  h + ":" + m + ":" + s;
  var t = setTimeout(startTime, 500);
}
function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}
</script>
</head>
<center>
<body style="color: #000;" onload="startTime()">
<div style="color: #fff;" id="txt"></div>
</center>
</body>
</html>
</div>

<hr/>
              </ul>
            </li>
            </ul>
        </div>