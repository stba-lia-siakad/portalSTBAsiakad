<?php $this->load->view("adminstba/layout_more/top") ?>

<?php $this->load->view('adminstba/layout/content/profil'); ?>

<?php $this->load->view("adminstba/layout_more/bottom") ?>