<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Barang extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('m_barang');
    }
     
    public function index(){
        $data['title'] = "Data Mahasiswa STBA per Tahun";       
        $this->load->view('adminstba/layout/content/statistik/statistik_view',$data, FALSE);
    }

    public function getData(){
        $this->load->model('Statistik_model');
        $data = $this->Statistik_model->getMahasiswa();
        echo json_encode($data);
        
    }

}