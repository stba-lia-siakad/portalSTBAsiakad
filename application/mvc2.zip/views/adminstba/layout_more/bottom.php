</div>
<footer class="footer">
            <?php $this->load->view("adminstba/layout/footer/footer") ?>
        </footer>

    </div>

                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </div>
        </div>


        
</div>


</body>

    <?php $this->load->view("adminstba/layout/footer/js") ?>

</html>
