<div class="container-fluid">
                
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> STBA LIA Yogyakarta</a> All right Reserved.
                </p>
                <p class="copyright pull-right">
                <img src="<?php echo base_url('assets/images/footer/download.png')?>" width="55"height="40"/>
                &nbsp;&nbsp;
                <img src="<?php echo base_url('assets/images/footer/kopertis.png')?>" width="45"height="40" />
                &nbsp;&nbsp;
                <img src="<?php echo base_url('assets/images/footer/mandiri.png')?>" width="60"height="40" />
                &nbsp;&nbsp;
                <img src="<?php echo base_url('assets/images/footer/blueT.png')?>" width="40"height="40" />
                </p>
            </div>